/*****************************************************************************************************************
NAME:    My Script Name
PURPOSE: My script purpose...

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     16/10/2025   KCHATIRA       1. Built this script for EC IT 143


RUNTIME: 
Xm Xs

NOTES: 
This is where I talk about what this script is, why I built it, and other stuff...
 
******************************************************************************************************************/

/* Question 1: How to keep track of when a record was last modified.

A:
--add a colomn for testing purposes
*/

alter table t_w3_schools_customers
add last_date_modified datetime default getdate();

-- Question 2: How to keep track of who last modified a record.

create trigger trg_t_w3_schools_last_mod on t_w3_schools_customers
after update
as
begin

    if exists (select 1 from inserted)
    begin
    update t
        set
            t.last_date_modified = getdate()
        from t_w3_schools_customers t
        inner join
            inserted i on t.ContactName = i.ContactName;

    end
end
go

-- test this, make a change:

update t_w3_schools_customers
set ContactName = 'Kevin Chatira'
where CustomerID = 11;


