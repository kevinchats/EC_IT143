update t_w3_schools_customers
set ContactName = 'Kevin Chatira'
where CustomerID = 11;