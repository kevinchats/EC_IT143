/* Question 1: How to keep track of when a record was last modified.

A:

*/

alter table t_w3_schools_customers
add last_date_modified datetime default getdate();

-- Question 2: How to keep track of who last modified a record.

create trigger trg_t_w3_schools_last_mod on t_w3_schools_customers
after update
as
begin

    if exists (select 1 from inserted)
    begin
    update t
        set
            t.last_date_modified = getdate()
        from t_w3_schools_customers t
        inner join
            inserted i on t.ContactName = i.ContactName;

    end
end
go


  



