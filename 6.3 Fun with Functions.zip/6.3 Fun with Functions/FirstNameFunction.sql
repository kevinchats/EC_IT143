create function udf_first_name
(@combined_name as varchar(500))
returns varchar(100)



	begin
		declare @first_name as varchar(100);
		set @first_name = left(@combined_name,charindex(' ',@combined_name + ' ') -1);
		return @first_name;
	end;
go



