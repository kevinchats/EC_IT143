select ContactName,
	LEFT(ContactName, charindex(' ',ContactName + ' ')-1) as FirstName
	
from t_w3_schools_customers
