with s1
	as(select ContactName,
		left(ContactName,charindex(' ',ContactName + ' ') -1) as first_name,
		dbo.udf_first_name(ContactName) as first_name2 from [dbo].[t_w3_schools_customers])
	select s1.*
		from s1
	where s1.first_name <> s1.first_name2;
