/*****************************************************************************************************************
NAME:    My Script Name
PURPOSE: My script purpose...

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     16/10/2025   KCHATIRA       1. Built this script for EC IT 143


RUNTIME:
Xm Xs

NOTES:
This is where I talk about what this script is, why I built it, and other stuff...

******************************************************************************************************************/

/* Question 2: How to extract the last name from the contact name

A:
First Method:
*/


select ContactName,
	LEFT(ContactName, charindex(' ',ContactName + ' ')-1) as FirstName

from t_w3_schools_customers

--Second Method:Create Function

create function udf_first_name
(@combined_name as varchar(500))
returns varchar(100)



	begin
		declare @first_name as varchar(100);
		set @first_name = left(@combined_name,charindex(' ',@combined_name + ' ') -1);
		return @first_name;
	end;
go

--Call FUNCTION

select ContactName,
	LEFT(ContactName, charindex(' ',ContactName + ' ')-1) as FirstName,
	dbo.udf_first_name(ContactName) as first_name2
from t_w3_schools_customers
order by 1;

--Test if both methods work

with s1
	as(select ContactName,
		left(ContactName,charindex(' ',ContactName + ' ') -1) as first_name,
		dbo.udf_first_name(ContactName) as first_name2 from [dbo].[t_w3_schools_customers])
	select s1.*
		from s1
	where s1.first_name <> s1.first_name2;
